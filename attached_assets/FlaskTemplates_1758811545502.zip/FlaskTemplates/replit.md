# BroadSens Sensor Management Tool

## Overview

This is a Flask-based web application for managing BroadSens sensor orders, customer information, site data, and automatic sensor ID assignments. The system handles the complete lifecycle of sensor orders from customer onboarding to sensor deployment, with features including customer and site management, sensor catalog management, order creation and tracking, automatic ID assignment, duplicate prevention, and data export capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: Flask with Jinja2 templating engine
- **UI Framework**: Bootstrap 5.3.0 with Font Awesome 6.0.0 icons
- **Architecture Pattern**: Server-side rendered templates with minimal client-side JavaScript
- **Responsive Design**: Mobile-first approach using Bootstrap's responsive grid system

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Design Pattern**: Monolithic architecture with route-based controllers
- **Data Models**: Python dataclasses for type safety and structure
- **Session Management**: Flask's built-in session handling with configurable secret key
- **ID Generation**: UUID-based unique identifiers for entities
- **Sensor ID Mapping**: Custom algorithm for generating sequential sensor IDs with corresponding group IDs

### Data Storage Solutions
- **Primary Storage**: JSON file-based database (`sensor_database.json`)
- **Data Format**: Structured JSON with separate collections for customers, sites, orders, and sensor assignments
- **Export Capability**: Excel export functionality using pandas for data analysis
- **Backup Strategy**: File-based storage allows for easy backup and version control

### Core Business Logic
- **Sensor Catalog**: Hardcoded BroadSens product catalog with sensor types and models
- **Automatic ID Assignment**: Sequential sensor ID assignment with duplicate prevention per sensor type per site
- **Order Management**: Complete order lifecycle from creation to fulfillment tracking
- **Capacity Management**: 3,844 sensor limit per sensor type per site

### Authentication and Authorization
- **Security Model**: Basic session-based security using Flask's secret key
- **Access Control**: No user authentication implemented - single-user administrative interface
- **Data Validation**: Server-side form validation for all user inputs

## External Dependencies

### Third-Party Libraries
- **Flask**: Core web framework for routing, templating, and request handling
- **pandas**: Data manipulation and Excel export functionality
- **Bootstrap**: Frontend CSS framework for responsive UI components
- **Font Awesome**: Icon library for enhanced user interface

### Frontend CDN Dependencies
- **Bootstrap CSS/JS**: `cdn.jsdelivr.net/npm/bootstrap@5.3.0`
- **Font Awesome**: `cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0`

### Python Standard Library
- **json**: JSON data serialization and parsing
- **os**: Environment variable access for configuration
- **datetime**: Timestamp generation and date handling
- **dataclasses**: Type-safe data structures
- **typing**: Type hints for better code documentation
- **uuid**: Unique identifier generation
- **re**: Regular expression operations for data validation

### File System Dependencies
- **JSON Database**: Local file storage for persistent data
- **Template Files**: HTML templates in `/templates` directory
- **Static Assets**: CSS, JavaScript, and image files (if any)
- **Export Files**: Temporary Excel files for data export functionality

### Environment Configuration
- **SESSION_SECRET**: Environment variable for Flask session security (fallback to hardcoded value)
- **File Permissions**: Read/write access to application directory for JSON database operations